package com.example.tip_calc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;

public class MainActivity extends AppCompatActivity
{
    public static final String TIP_AMOUNT = "com.example.application.my_tip_calc.TIP_AMOUNT";
    public static final String TOTAL_BILL = "com.example.application.my_tip_calc.TOTAL_BILL";

    Button button_tip_percent_up;
    Button button_tip_percent_down;
    Button button_calculate;
    EditText edittext_decimal_bill_amount;
    TextView edittext_decimal_tip_percent;
    TextView edittext_decimal_tip_amount;
    TextView edittext_decimal_total_bill;

    Double bill_amount;
    Double tip_percent;
    Double tip_amount;
    Double total_bill;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_tip_percent_up = (Button) findViewById(R.id.button_tip_percent_up);
        button_tip_percent_down = (Button) findViewById(R.id.button_tip_percent_down);
        edittext_decimal_bill_amount = (EditText) findViewById(R.id.edittext_decimal_bill_amount);
        edittext_decimal_tip_percent = (TextView) findViewById(R.id.edittext_decimal_tip_percent);
        edittext_decimal_tip_amount = (TextView) findViewById(R.id.edittext_decimal_tip_amount);
        edittext_decimal_total_bill = (TextView) findViewById(R.id.edittext_decimal_total_bill);

        bill_amount = 0.0;
        tip_percent = 20.0;
        tip_amount = 0.0;
        total_bill = 0.0;

        edittext_decimal_bill_amount.setText("$" + bill_amount.toString());
        edittext_decimal_tip_percent.setText(tip_percent.toString() + "%");
    }

    public void increase_tip(View view)
    {
        tip_percent = tip_percent + 1;
        edittext_decimal_tip_percent.setText(tip_percent.toString() + "%");
    }

    public void decrease_tip(View view)
    {
        if (tip_percent > 0)
        {
            tip_percent = tip_percent - 1;
            edittext_decimal_tip_percent.setText(tip_percent.toString() + "%");
        }
    }

    public void calculate_total_bill(View view)
    {
        if (edittext_decimal_bill_amount.getText().toString().charAt(0) != '$')
        {
            edittext_decimal_bill_amount.setText("$" + edittext_decimal_bill_amount.getText().toString());
        }

        if (edittext_decimal_bill_amount.getText().toString().substring(1).matches(""))
        {
            bill_amount = 0.0;
        }
        else
        {
            bill_amount = Double.parseDouble(edittext_decimal_bill_amount.getText().toString().substring(1));
        }


        tip_amount = bill_amount * (tip_percent / 100);
        edittext_decimal_tip_amount.setText("$" + String.format("%.2f", tip_amount));

        total_bill = bill_amount + tip_amount;
        edittext_decimal_total_bill.setText("$" + String.format("%.2f", total_bill));
    }

    public void open_split_tip(View view)
    {
        Intent intent = new Intent(this, split_tip.class);
        intent.putExtra(TIP_AMOUNT, tip_amount);
        intent.putExtra(TOTAL_BILL, total_bill);
        startActivity(intent);
    }
}