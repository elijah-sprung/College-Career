package com.example.tip_calc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;

public class split_tip extends AppCompatActivity
{
    Button button_num_people_up;
    Button button_num_people_down;
    Button button_calculate;
    TextView edittext_total_bill;
    TextView edittext_tip_amount;
    TextView textview_num_split;
    TextView textview_total_cost;
    Double tip_amount;
    Double total_amount;
    Integer num_people;
    Double split_cost;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.split_tip);

        Intent intent = getIntent();
        tip_amount = intent.getDoubleExtra(MainActivity.TIP_AMOUNT, 0.0);
        total_amount = intent.getDoubleExtra(MainActivity.TOTAL_BILL, 0.0);

        edittext_tip_amount = (TextView) findViewById(R.id.edittext_decimal_tip_amount);
        edittext_total_bill = (TextView) findViewById(R.id.edittext_decimal_total_bill);
        edittext_total_bill.setText("$" + String.format("%.2f", total_amount));
        edittext_tip_amount.setText("$" + String.format("%.2f", tip_amount));

        button_num_people_up = (Button) findViewById(R.id.button_num_split_up);
        button_num_people_down = (Button) findViewById(R.id.button_num_split_down);

        textview_num_split = (TextView) findViewById(R.id.textview_num_split);
        textview_total_cost = (TextView) findViewById(R.id.textview_total_cost);

        num_people = 1;
        split_cost = 0.00;

        textview_num_split.setText(num_people.toString());
    }

    public void num_people_up(View view)
    {
        num_people = num_people + 1;
        textview_num_split.setText(num_people.toString());
    }

    public void num_people_down(View view)
    {
        if (num_people > 0)
        {
            num_people = num_people - 1;
            textview_num_split.setText(num_people.toString());
        }
        else
        {
            num_people = 0;
            textview_num_split.setText(num_people.toString());
        }
    }

    public void calculate_split(View view)
    {
        if (num_people != 0)
        {
            split_cost = tip_amount / num_people;
            textview_total_cost.setText("$" + String.format("%.2f", split_cost));
        }
        else
        {
            split_cost = 0.00;
            textview_total_cost.setText("$" + String.format("%.2f", split_cost));
        }
    }
}