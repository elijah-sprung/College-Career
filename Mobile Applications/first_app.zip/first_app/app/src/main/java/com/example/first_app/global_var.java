package com.example.first_app;

public class global_var {
    public static Integer num_drinks = 0;
}
