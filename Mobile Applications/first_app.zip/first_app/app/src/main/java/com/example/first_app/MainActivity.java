package com.example.first_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    String[] urls = new String[] {
            "https://vinepair.com/cocktail-recipe/sidecar/",
            "https://vinepair.com/cocktail-recipe/corpse-reviver-2/",
            "https://vinepair.com/cocktail-recipe/blood-and-sand/",
            "https://vinepair.com/cocktail-recipe/the-tommys-margarita/",
            "https://vinepair.com/cocktail-recipe/irish-coffee-recipe/",
            "https://vinepair.com/cocktail-recipe/the-last-word-recipe/",
            "https://vinepair.com/cocktail-recipe/the-painkiller-recipe/",
            "https://vinepair.com/cocktail-recipe/the-hanky-panky/",
            "https://vinepair.com/cocktail-recipe/the-ramos-gin-fizz-recipe/",
            "https://vinepair.com/cocktail-recipe/bellini/",
            "https://vinepair.com/cocktail-recipe/the-bees-knees-recipe/",
            "https://vinepair.com/cocktail-recipe/long-island-iced-tea-recipe/",
            "https://vinepair.com/cocktail-recipe/the-aviation-cocktail/",
            "https://vinepair.com/cocktail-recipe/vesper/",
            "https://vinepair.com/cocktail-recipe/the-vodka-martini/",
            "https://vinepair.com/cocktail-recipe/sazerac/",
            "https://vinepair.com/cocktail-recipe/the-zombie-recipe/",
            "https://vinepair.com/cocktail-recipe/vieux-carre/",
            "https://vinepair.com/cocktail-recipe/amaretto-sour-recipe/",
            "https://vinepair.com/cocktail-recipe/pina-colada/",
            "https://vinepair.com/cocktail-recipe/caipirinha/",
            "https://vinepair.com/cocktail-recipe/gin-fizz/",
            "https://vinepair.com/cocktail-recipe/dark-n-stormy/",
            "https://vinepair.com/cocktail-recipe/clover-club/",
            "https://vinepair.com/cocktail-recipe/pisco-sour/",
            "https://vinepair.com/cocktail-recipe/mai-tai-recipe/",
            "https://vinepair.com/cocktail-recipe/gimlet/",
            "https://vinepair.com/cocktail-recipe/french-75/",
            "https://vinepair.com/cocktail-recipe/americano/",
            "https://vinepair.com/cocktail-recipe/bloody-mary/",
            "https://vinepair.com/cocktail-recipe/paloma/",
            "https://vinepair.com/cocktail-recipe/penicillin-scotch-cocktail-recipe/",
            "https://vinepair.com/cocktail-recipe/boulevardier/",
            "https://vinepair.com/cocktail-recipe/moscow-mule-recipe/",
            "https://vinepair.com/cocktail-recipe/whiskey-sour-recipe/",
            "https://vinepair.com/cocktail-recipe/mojito/",
            "https://vinepair.com/cocktail-recipe/manhattan/",
            "https://vinepair.com/cocktail-recipe/the-espresso-martini-recipe/",
            "https://vinepair.com/cocktail-recipe/ultimate-aperol-spritz-recipe/",
            "https://vinepair.com/cocktail-recipe/daiquiri/",
            "https://vinepair.com/cocktail-recipe/margarita/",
            "https://vinepair.com/cocktail-recipe/gin-martini/",
            "https://vinepair.com/cocktail-recipe/old-fashioned/",
            "https://vinepair.com/cocktail-recipe/negroni/",
    };

    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView_num_drinks = (TextView) findViewById(R.id.textView_num_drinks);
        ImageView imageView_meme = (ImageView) findViewById(R.id.imageView_meme);

        textView_num_drinks.setText(global_var.num_drinks.toString());
        if(global_var.num_drinks >= 10) {
            imageView_meme.setVisibility(View.VISIBLE);
        }else{
            imageView_meme.setVisibility(View.INVISIBLE);
        }
    }

    public void open_webview(View view)
    {
        String rand_url = urls[(0 + random.nextInt(urls.length - 0 + 1))];
        global_var.num_drinks = global_var.num_drinks + 1;

        Intent intent = new Intent(this, webview.class);
        intent.putExtra("EXTRA_SESSION_ID", rand_url);
        startActivity(intent);
    }
}


