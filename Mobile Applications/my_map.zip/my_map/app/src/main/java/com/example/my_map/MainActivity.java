package com.example.my_map;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editText_input_search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText_input_search = (EditText) findViewById(R.id.editText_input_search);
    }

    public void open_map(View view)
    {
        if (TextUtils.isEmpty(editText_input_search.getText().toString()))
        {
            Toast.makeText(MainActivity.this,
                    "Empty field not allowed!",
                    Toast.LENGTH_SHORT).show();
        }
        else
        {
            String search = editText_input_search.getText().toString();
            Intent intent = new Intent(this, MapsActivity.class);
            intent.putExtra("EXTRA_SESSION_ID", search);
            startActivity(intent);
        }
    }
}